To decrypt, use the same strength and key that you used for encrypting.

The key is case sensitive.
You won't be able to decrypt a file with a different key or strength. Exception:
'Default' strength = 'Normal' strength. 
(using 'Default' for encrypting and 'Normal' for decrypting, and vice-versa, works fine).

Important: if the decrypted files are corrupted, and no errors are shown, that means the file "PadlockU.exe.config" is missing.
If you intend to use this application, make sure "PadlockU.exe" and "PadlockU.exe.config" are in the same folder.
Do NOT modify the config.